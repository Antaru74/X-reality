package com.xreality;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;

import java.lang.reflect.Method;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage.LoadPackageParam;

/** Mendaftarkan matriks X-Reality sebagai level sendiri di DisplayTransformManager. */
public class Hook implements IXposedHookLoadPackage {
    static final String KEY = "xreality_enabled";
    static final int LEVEL = 350;               // sama seperti crDroid: di atas invert color
    static final int PHASE_BOOT_COMPLETED = 1000;
    static final String PKG = "com.android.server.display.color.";

    private static Object dtm;
    private static Method setMatrix, needsLinear;
    private static ContentResolver cr;
    private static boolean ready;

    @Override
    public void handleLoadPackage(LoadPackageParam lp) {
        if (!"android".equals(lp.packageName)) return;
        try {
            final ClassLoader cl = lp.classLoader;
            final Class<?> dtmCls = XposedHelpers.findClass(PKG + "DisplayTransformManager", cl);
            final Class<?> cds = XposedHelpers.findClass(PKG + "ColorDisplayService", cl);
            setMatrix = dtmCls.getMethod("setColorMatrix", int.class, float[].class);
            needsLinear = dtmCls.getMethod("needsLinearColorMatrix");

            // color mode berubah -> matriks linear/gamma bisa berubah
            XposedBridge.hookAllMethods(dtmCls, "setColorMode", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) { apply(); }
            });

            XposedBridge.hookAllMethods(cds, "onBootPhase", new XC_MethodHook() {
                @Override protected void afterHookedMethod(MethodHookParam p) {
                    if (ready || !(p.args[0] instanceof Integer)
                            || (Integer) p.args[0] != PHASE_BOOT_COMPLETED) return;
                    try {
                        Context ctx = (Context) XposedHelpers.callMethod(p.thisObject, "getContext");
                        Class<?> ls = XposedHelpers.findClass("com.android.server.LocalServices", cl);
                        dtm = XposedHelpers.callStaticMethod(ls, "getService", dtmCls);
                        cr = ctx.getContentResolver();
                        cr.registerContentObserver(Settings.Secure.getUriFor(KEY), false,
                                new ContentObserver(new Handler(Looper.getMainLooper())) {
                                    @Override public void onChange(boolean selfChange) { apply(); }
                                });
                        ready = true;
                        apply();
                    } catch (Throwable t) {
                        XposedBridge.log("XReality init: " + t);
                    }
                }
            });
        } catch (Throwable t) {
            XposedBridge.log("XReality hook: " + t);
        }
    }

    static synchronized void apply() {
        if (!ready || dtm == null || cr == null) return;
        try {
            boolean on = Settings.Secure.getInt(cr, KEY, 0) == 1;
            float[] m = on ? Engine.build((Boolean) needsLinear.invoke(dtm)) : null;
            setMatrix.invoke(dtm, LEVEL, m);
        } catch (Throwable t) {
            XposedBridge.log("XReality apply: " + t);
        }
    }
}
