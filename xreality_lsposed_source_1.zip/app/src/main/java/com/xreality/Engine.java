package com.xreality;

import android.opengl.Matrix;

/** Matriks mode X-Reality, port dari crDroid DisplayEngineController (hue = 0). */
final class Engine {
    private static final float GAMMA = 2.2f;
    private static final float[] LUMA_GAMMA = {0.3086f, 0.6094f, 0.0820f};
    private static final float[] LUMA_LINEAR = {0.2126f, 0.7152f, 0.0722f};
    // R, G, B, saturasi, kontras, value (skala 255)
    private static final int[] P = {252, 227, 228, 278, 260, 264};

    static float[] build(boolean linear) {
        float[] m = new float[16];
        Matrix.setIdentityM(m, 0);
        m[0] = gain(P[0], linear);
        m[5] = gain(P[1], linear);
        m[10] = gain(P[2], linear);

        float c = P[4] / 255f;
        float pivot = linear ? (float) Math.pow(0.5, GAMMA) : 0.5f;
        float t = (1f - c) * pivot;
        pre(m, new float[]{c, 0, 0, 0, 0, c, 0, 0, 0, 0, c, 0, t, t, t, 1});

        float v = P[5] / 255f;
        if (linear) v = (float) Math.pow(v, GAMMA);
        pre(m, new float[]{v, 0, 0, 0, 0, v, 0, 0, 0, 0, v, 0, 0, 0, 0, 1});

        float s = P[3] / 255f;
        float[] l = linear ? LUMA_LINEAR : LUMA_GAMMA;
        float i = 1f - s, r = i * l[0], g = i * l[1], b = i * l[2];
        pre(m, new float[]{r + s, r, r, 0, g, g + s, g, 0, b, b, b + s, 0, 0, 0, 0, 1});

        normalize(m);
        return m;
    }

    private static float gain(int ch, boolean linear) {
        float g = ch / 255f;
        return linear ? (float) Math.pow(g, GAMMA) : g;
    }

    private static void pre(float[] m, float[] lhs) {
        float[] tmp = new float[16];
        Matrix.multiplyMM(tmp, 0, lhs, 0, m, 0);
        System.arraycopy(tmp, 0, m, 0, 16);
    }

    private static void normalize(float[] m) {
        float norm = 1f;
        for (int r = 0; r < 3; r++) {
            norm = Math.max(norm, m[r] + m[4 + r] + m[8 + r] + m[12 + r]);
        }
        for (int i = 0; i < 15; i++) {
            if (i == 3 || i == 7 || i == 11) continue;
            norm = Math.max(norm, Math.abs(m[i]));
        }
        if (norm <= 1f) return;
        float inv = 1f / norm;
        for (int i = 0; i < 15; i++) {
            if (i == 3 || i == 7 || i == 11) continue;
            m[i] *= inv;
        }
        m[15] = 1f;
    }
}
