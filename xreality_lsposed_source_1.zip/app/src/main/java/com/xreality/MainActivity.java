package com.xreality;

import android.app.Activity;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private boolean ignore;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        int pad = (int) (24 * getResources().getDisplayMetrics().density);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER_VERTICAL);
        root.setPadding(pad, pad, pad, pad);

        TextView title = new TextView(this);
        title.setText("X-Reality Engine");
        title.setTextSize(24);
        TextView info = new TextView(this);
        info.setText("Mode X-Reality dari crDroid, didaftarkan sebagai level warna sistem sehingga tetap aktif bersama Extra Dim dan Night Light. Aktifkan modul di LSPosed (scope: System Framework), lalu reboot.");
        info.setPadding(0, pad / 2, 0, pad);

        final Switch sw = new Switch(this);
        sw.setText("Aktifkan X-Reality");
        sw.setTextSize(18);
        sw.setChecked(Settings.Secure.getInt(getContentResolver(), Hook.KEY, 0) == 1);
        sw.setOnCheckedChangeListener((v, on) -> {
            if (ignore) return;
            new Thread(() -> {
                boolean ok = su("settings put secure " + Hook.KEY + " " + (on ? 1 : 0));
                runOnUiThread(() -> {
                    if (!ok) {
                        Toast.makeText(this, "Gagal. Beri akses root ke aplikasi ini.", Toast.LENGTH_LONG).show();
                        ignore = true;
                        sw.setChecked(!on);
                        ignore = false;
                    }
                });
            }).start();
        });

        root.addView(title);
        root.addView(info);
        root.addView(sw);
        setContentView(root);
    }

    private static boolean su(String cmd) {
        try {
            Process p = Runtime.getRuntime().exec(new String[]{"su", "-c", cmd});
            return p.waitFor() == 0;
        } catch (Exception e) {
            return false;
        }
    }
}
