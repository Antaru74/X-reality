# X-Reality Engine (LSPosed)
1. Buat repo GitHub, push seluruh isi folder ini (termasuk .github).
2. Tab Actions > build > Run workflow. Unduh artifact `xreality-engine-apk`.
3. Pasang APK, aktifkan di LSPosed dengan scope System Framework (android), reboot.
4. Buka aplikasi, beri akses root, nyalakan switch. Matikan modul KernelSU xreality_engine lama.
